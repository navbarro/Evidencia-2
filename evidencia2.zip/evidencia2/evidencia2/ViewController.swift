//
//  ViewController.swift
//  evidencia2
//
//  Created by Juan Miguel Flores on 10/04/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func unwindToQuizIntroduction(segue:
    UIStoryboardSegue) {
        
    }
}

